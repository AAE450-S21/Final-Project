function [df, dg] = dfg(r0_vect, v0_vect,TA, p, mu)
    r0 = norm(r0_vect);
    df = dot(r0_vect,v0_vect)/(p*r0)*(1-cosd(TA))-1/r0*sqrt(mu/p)*sind(TA);
    dg = 1-r0/p*(1-cosd(TA));
end
