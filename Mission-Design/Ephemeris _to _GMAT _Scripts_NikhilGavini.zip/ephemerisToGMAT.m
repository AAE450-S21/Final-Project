%%% AAE 450 - Ephemeris to GMAT Input Script
%%% Author: Nikhil Gavini

clear;
clc;

%% READ BEFORE USING
% The default transfer angle is 175 degrees and the default TOF is 4.00 days
% If changed, you must change the excel filename as well as the GMAT_inputs script

%% Set up connection to Excel File Sheet that has Ephemeris Data
fileName = 'Lambert_Numbers_Earth_to_Moon_175_400.xlsx';      % Excel File Name in Directory
for year = 1:10
    yearNumber = year;                      % Year that you want data from
    if (year == 2 || year == 6 || year == 9)
        numLaunches = 14;
        cellRange = 'C3:E16';               % C3 to E (2 + numLaunches)
    else
        numLaunches = 13;
        cellRange = 'C3:E15';               % C3 to E (2 + numLaunches)
    end                   

    %% Read in Ephemeris Data
    ephemeris = xlsread(fileName, yearNumber, cellRange);

    %% Create Tables to be filled in by GMAT inputs and Additional Characteristics
    characteristic_table = cell2table(cell(numLaunches, 6));
    characteristic_table_headers = {'a', 'e', 'i', 'RAAN', 'AoP', 'TA_dep'};
    characteristic_table.Properties.VariableNames = characteristic_table_headers;

    additional_table = cell2table(cell(numLaunches, 2));
    additional_table_headers = {'Type', 'DeltaV'};
    additional_table.Properties.VariableNames = additional_table_headers;

    %% Fill in Table with GMAT Inputs
    for index = 1:numLaunches
        % Input Data from Ephemeris
        luna_range = ephemeris(index, 1);
        alpha_arr = ephemeris(index, 2);
        delta_arr = ephemeris(index, 3);

        % Get Orbit Characteristics
        [a, e, inclination, RAAN, AoP, theta_star_dep, TRANSFER_TYPE, dv1] = GMAT_inputs(luna_range, alpha_arr, delta_arr);

        % Put Orbit Characteristics into Tables
        characteristic_table{index, 1} = num2cell(a);
        characteristic_table{index, 2} = num2cell(e);
        characteristic_table{index, 3} = num2cell(inclination);
        characteristic_table{index, 4} = num2cell(RAAN);
        characteristic_table{index, 5} = num2cell(AoP);
        characteristic_table{index, 6} = num2cell(theta_star_dep);
        additional_table{index, 1} = cellstr(TRANSFER_TYPE);
        additional_table{index, 2} = num2cell(dv1);

    end

    %% Write Data into Excel Cells in Original File
    xlswrite(fileName, table2cell(characteristic_table), yearNumber, 'G3');
    xlswrite(fileName, table2cell(additional_table), yearNumber, 'P3');
    
    %% Let users know of progress
    fprintf('Year %d is written. \n', yearNumber);
end

clear;
clc;

fprintf('Excel Sheet has been populated with GMAT inputs. \n');