%% Orbit 3D
clc
clear all
close all

%% Read in Lambert Data
GeneralLambert;

%% Input Desired Inclination, right ascension, and declination
i = 28.5;
alpha = 34.7293; % INPUT
delta = 11.93773; % INPUT

solve_fun = @(x) solve_orb(x, delta, alpha, i);
kepler_angles = fsolve(solve_fun, [0 0]);
RAAN = kepler_angles(1);
theta = kepler_angles(2);

AOP = mod(theta,360)-mod(theta_star_arr,360);

a
e
RAAN = mod(RAAN, 360)
i
AOP=mod(AOP,360)
theta_star_dep = mod(theta_star_dep,360)