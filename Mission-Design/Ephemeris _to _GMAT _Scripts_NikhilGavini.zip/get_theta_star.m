function [theta_star_dep, theta_star_arr] = get_theta_star(p, e, r_dep, r_arr, TA)
    theta_star_dep_vals = acosd((p/r_dep-1)/e);
    theta_star_arr_vals = acosd((p/r_arr-1)/e);
    
    theta_star_dep_vals = [theta_star_dep_vals, -theta_star_dep_vals];
    theta_star_arr_vals = [theta_star_arr_vals, -theta_star_arr_vals+360];
    
    diffs = [theta_star_arr_vals-theta_star_dep_vals(1), theta_star_arr_vals-theta_star_dep_vals(2)];
    
    corr_val = find(abs(diffs-TA)<1e-4);
    
    switch corr_val
        case 1
            theta_star_dep = theta_star_dep_vals(1);
            theta_star_arr = theta_star_arr_vals(1);
        case 2
            theta_star_dep = theta_star_dep_vals(1);
            theta_star_arr = theta_star_arr_vals(2);
        case 3
            theta_star_dep = theta_star_dep_vals(2);
            theta_star_arr = theta_star_arr_vals(1);
        case 4
            theta_star_dep = theta_star_dep_vals(2);
            theta_star_arr = theta_star_arr_vals(2);
    end
    if theta_star_arr > 180
        theta_star_arr = theta_star_arr-360;
    end
    
    