function [f g] = fg(r0, rf, TA, p, mu)
    f = 1-rf/p*(1-cosd(TA));
    g = rf*r0/sqrt(mu*p)*sind(TA);