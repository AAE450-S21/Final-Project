function orb_angles = solve_orb(x, delta, alpha, i)
       
    orb_angles(1) = cosd(x(1))*cosd(x(2))-sind(x(1))*cosd(i)*sind(x(2))-...
        cosd(delta)*cosd(alpha);
    orb_angles(2) = sind(x(1))*cosd(x(2))+cosd(x(1))*cosd(i)*sind(x(2))-...
        cosd(delta)*sind(alpha);
    orb_angles(3) = sind(i)*sind(x(2))-sind(delta);
