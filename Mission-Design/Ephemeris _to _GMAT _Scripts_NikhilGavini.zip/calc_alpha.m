function alpha = calc_alpha(dv_vnb)
    beta = asind(dv_vnb(2)/norm(dv_vnb));
    
    alphac = acosd(dv_vnb(1)/(cosd(beta)*norm(dv_vnb)));
    alphac = [alphac -alphac];
    
    alphas = asind(dv_vnb(3)/(cosd(beta)*norm(dv_vnb)));
    alphas = [alphas 180-alphas];
    
    for i=1:2
        if alphac(i) < 0
            alphac(i) = alphac(i) + 360;
        end
        if alphas(i) < 0
            alphas(i) = alphas(i) + 360;
        end
    end
    
    for i=1:2
        if abs(alphac(i)-alphas(1)) < 1e-4
            alpha = alphas(1);
        end
        if abs(alphac(i)-alphas(2)) < 1e-4
            alpha = alphas(2);
        end
    end
    