function rot_mat = rth2xyz(Omega, i, theta)
    rot_mat=zeros(3);
    
    rot_mat(1,1) = cosd(theta)*cosd(Omega)-cosd(i)*sind(Omega)*sind(theta);
    rot_mat(1,2) = -sind(theta)*cosd(Omega)-cosd(theta)*cosd(i)*sind(Omega);
    rot_mat(1,3) = sind(i)*sind(Omega);
    
    rot_mat(2, 1) = cosd(theta)*sind(Omega)+sind(theta)*cosd(i)*cosd(Omega);
    rot_mat(2, 2) = -sind(theta)*sind(Omega)+cosd(theta)*cosd(i)*cosd(Omega);
    rot_mat(2, 3) = -sind(i)*cosd(Omega);
    
    rot_mat(3,1) = sind(i)*sind(theta);
    rot_mat(3,2) = cosd(theta)*sind(i);
    rot_mat(3,3) = cosd(i);
    
    
  