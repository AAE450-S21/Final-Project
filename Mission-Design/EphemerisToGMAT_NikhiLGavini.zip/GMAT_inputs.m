function [a, e, inclination, RAAN, AoP, theta_star_dep, TRANSFER_TYPE, dv1] = GMAT_inputs(luna_range, alpha_arr, delta_arr)
    %% Inputs
    transfer_angle = 175;
    desired_TOF_days = 4;

    %% Get Inclination, Argument of Latitude (theta), Right Ascension (Upper Omega)
    inclination = 28.5; % Minimum 28.5 deg (Cape Canaveral)
    AoL = asind(sind(delta_arr)/sind(inclination));

    % Solve for RAAN
    % fprintf('%.4f * c_RAAN - %.4f * s_RAAN = %.4f \n', cosd(AoL), cosd(inclination)*sind(AoL), cosd(alpha_arr)*cosd(delta_arr));
    % fprintf('%.4f * c_RAAN + %.4f * s_RAAN = %.4f \n', cosd(inclination)*sind(AoL), cosd(AoL), sind(alpha_arr)*cosd(delta_arr));

    % Solve for RAAN
    RAAN_consts = [cosd(AoL), -cosd(inclination)*sind(AoL); cosd(inclination)*sind(AoL), cosd(AoL)];
    sol = [cosd(alpha_arr)*cosd(delta_arr); sind(alpha_arr)*cosd(delta_arr)];

    RAAN_const_matrix = [RAAN_consts sol];
    RAAN_const_solns = rref(RAAN_const_matrix);

    RAAN1 = acosd(RAAN_const_solns(1,3));
    RAAN2 = 360-acosd(RAAN_const_solns(1,3));
    RAAN3 = asind(RAAN_const_solns(2,3));
    RAAN4 = 180 - asind(RAAN_const_solns(2,3));

    RAANmatrix = [RAAN1 RAAN2; RAAN3 RAAN4];
    if (floor(abs(RAAN1)) == floor(abs(RAAN3)))
        RAAN = RAAN1;
    elseif (floor(abs(RAAN1)) == floor(abs(RAAN4)))
        RAAN = RAAN1;
    elseif (floor(abs(RAAN2)) == floor(abs(RAAN3)))
        RAAN = RAAN2;
    elseif (floor(abs(RAAN2)) == floor(abs(RAAN4)))
        RAAN = RAAN2;
    end


    %% Known Constants and Parameters
    mu_earth = 398600; % Gravitation Parameter of Earth
    mu_moon = 4902.8005821478;  % Gravitation Parameter of Moon
    TA = transfer_angle; % Transfer angle (degrees)
    TOF = desired_TOF_days*3600*24; % Time of flight (seconds)

    if TA < 180
        TRANSFER_NUM = 1; % Transfer Type Number (1 or 2)
    else
        TRANSFER_NUM = 2;
    end

    %% Departure Quantities and Space Triangle Geometry

    % Departure Radii
    r_dep = 6378+600;   % Earth Radius 
    r_arr = luna_range;

    if TRANSFER_NUM == 1
        c = sqrt(r_dep^2+r_arr^2-2*r_dep*r_arr*cosd(TA));
    else
        c = sqrt(r_dep^2+r_arr^2-2*r_dep*r_arr*cosd(360-TA));
    end

    % Compute Space Triangle Semi-Perimeter
    s = (r_arr+r_dep+c)/2;

    %% Parabolic TOF and Transfer Type
    a_min = s/2;
    TOF_min = 0;

    % Determine Parabolic TOF
    if TRANSFER_NUM == 1
        TOF_par = 1/3*sqrt(2/mu_earth)*(s^(3/2)-(s-c)^(3/2)); 

    else
        TOF_par = 1/3*sqrt(2/mu_earth)*(s^(3/2)+(s-c)^(3/2));
    end

    %% Determine Transfer Geometry (ELLIPIC or HYPERBOLIC)
    if TOF > TOF_par
        TRANSFER_GEOMETRY = "ELLIPTIC";
        alpha_min = 2*asin(sqrt(s/(2*a_min)));
        beta_min = 2*asin(sqrt((s-c)/(2*a_min)));
        TOF_min = sqrt(a_min^3/mu_earth)*((alpha_min-beta_min)-(sin(alpha_min)-sin(beta_min)));

        if TOF>TOF_min
            TRANSFER_TYPE = num2str(TRANSFER_NUM)+"B";
        else
            TRANSFER_TYPE = num2str(TRANSFER_NUM)+"A";
        end

    else
        TRANSFER_GEOMETRY = "HYPERBOLIC";
        TRANSFER_TYPE = num2str(TRANSFER_NUM)+"H";
    end

    %% Select Appropriate alpha/beta fcns
    alpha_fcn = @(a) 0;
    beta_fcn = @(b) 0;
    lambert_fcn = @(a) 0;

    switch TRANSFER_TYPE
        case "1A"
            alpha_fcn = @(a) 2*asin(sqrt(s/(2*a)));
            beta_fcn = @(a) 2*asin(sqrt((s-c)/(2*a)));
        case "2B"
            alpha_fcn = @(a) 2*pi-2*asin(sqrt(s/(2*a)));
            beta_fcn = @(a) -2*asin(sqrt((s-c)/(2*a)));
        case "1B"
            alpha_fcn = @(a) 2*pi - 2*asin(sqrt(s/(2*a)));
            beta_fcn = @(a) 2*asin(sqrt((s-c)/(2*a)));
        case "2A"
            alpha_fcn = @(a) 2*asin(sqrt(s/(2*a)));
            beta_fcn = @(a) -2*asin(sqrt((s-c)/(2*a)));
        case "1H"
            alpha_fcn = @(a) 2*asinh(sqrt(s/(2*abs(a))));
            beta_fcn = @(a) 2*asinh(sqrt((s-c)/(2*abs(a))));
        case "2H"
             alpha_fcn = @(a) 2*asinh(sqrt(s/(2*abs(a))));
              beta_fcn = @(a) -2*asinh(sqrt((s-c)/(2*abs(a))));
    end

    %% Select Appropriate lambert function
    guess = a_min;
    switch TRANSFER_GEOMETRY
        case "ELLIPTIC"
            lambert_fcn = @(a) sqrt(a^3/mu_earth)*((alpha_fcn(a)-sin(alpha_fcn(a)))-...
                (beta_fcn(a)-sin(beta_fcn(a))))-TOF;
            guess = a_min;
        case "HYPERBOLIC"
            lambert_fcn = @(a) sqrt(abs(a)^3/mu_earth)*((sinh(alpha_fcn(a))-alpha_fcn(a))-...
                (sinh(beta_fcn(a))-beta_fcn(a)))-TOF;
            guess = -(r_dep+r_arr)/2;
    end

    %% Solve Lambert
    a = fsolve(lambert_fcn, guess);
    alpha_val = alpha_fcn(a);
    beta_val = beta_fcn(a);
    if abs(lambert_fcn(a)) > 1e-4
        fprintf("ERROR! BAD A");
        5/0;
    end

    %% Compute p
    % Elliptic Case
    if TRANSFER_GEOMETRY == "ELLIPTIC"
        p1 = 4*a*(s-r_dep)*(s-r_arr)/c^2*(sin((alpha_val+beta_val)/2))^2;
        p2 = 4*a*(s-r_dep)*(s-r_arr)/c^2*(sin((alpha_val-beta_val)/2))^2;

        if TRANSFER_TYPE == "1A" || TRANSFER_TYPE == "2B"
            p = max(p1, p2);
        else
            p = min(p1,p2);
        end

    % Hyperbolic Case    
    else
        p1 = 4*abs(a)*(s-r_dep)*(s-r_arr)/c^2*(sinh((alpha_val+beta_val)/2))^2;
        p2 = 4*abs(a)*(s-r_dep)*(s-r_arr)/c^2*(sinh((alpha_val-beta_val)/2))^2;
        if TRANSFER_TYPE == "1H"
            p = max(p1, p2);
        else
            p = min(p1,p2);
        end
    end

    %% General Orbit Characteristics
    if TRANSFER_GEOMETRY == "ELLIPTIC"
        e = sqrt(1-p/a);
    else
        e = sqrt(1+p/abs(a));
    end

    spec_E = -mu_earth/(2*a);
    v_dep = sqrt(2*(spec_E+mu_earth/r_dep));
    v_arr = sqrt(2*(spec_E+mu_earth/r_arr));

    [theta_star_dep, theta_star_arr] = get_theta_star(p, e, r_dep, r_arr, TA);
    AoP = AoL - theta_star_arr;
    if (AoP < 0)
        AoP = AoP + 360;
    end
    gamma_dep = sign(theta_star_dep)*acosd(sqrt(mu_earth*p)/(r_dep*v_dep));
    gamma_arr = sign(theta_star_arr)*acosd(sqrt(mu_earth*p)/(r_arr*v_arr));

    rp = a*(1-e);
    ra = a*(1+e);

    %% Print Useful Characteristics

%     fprintf('\nDesired Transfer Angle = %.2f deg \n', transfer_angle);
%     fprintf('Desired TOF = %.2f days \n', desired_TOF_days);
%     fprintf('Earth-Luna Lambert Type: Type %s Transfer \n\n', TRANSFER_TYPE);
% 
%     fprintf('GMAT Keplerian Inputs:\n');
%     fprintf('a = %.8f km \n', a);
%     fprintf('e = %.8f \n', e);
%     fprintf('Inclination = %.8f deg \n', inclination);
%     fprintf('RAAN (omega) = %.8f deg \n', RAAN);
%     fprintf('Argument of Periapsis (w) = %.8f deg \n', AoP);
%     fprintf('TA_dep = %.8f deg \n', theta_star_dep);
    %fprintf('TA_arr = %.8f deg \n', theta_star_arr);
    %fprintf('Argument of Latitude (theta) = %.8f deg \n', AoL);
    %% Delta-Vs Using F and G

    v_0_xyz = sqrt(mu_earth/r_dep)*[0 1 0]';
    v_f_xyz = sqrt(mu_earth/r_arr)*[cosd(TA+90) sind(TA+90) 0]';

    r_dep_xyz = r_dep * [1 0 0]';
    r_arr_xyz = r_arr * [cosd(TA) sind(TA) 0]';

    [f, g] = fg(r_dep, r_arr, TA, p, mu_earth);

    v_dep_xyz = (r_arr_xyz - r_dep_xyz*f)/g;

    [df, dg] = dfg(r_dep_xyz, v_dep_xyz, TA, p, mu_earth);

    v_arr_xyz = df*r_dep_xyz + dg*v_dep_xyz;

    dv1_vnb = rt2vnb(0)*rth2xyz(0, 0, 0)'*(v_dep_xyz-v_0_xyz);
    dv1 = norm(dv1_vnb);
    %fprintf('\nDeltaV1 to escape Earth Parking Orbit = %.4f km/s \n', dv1);

    dv2_vnb = rt2vnb(gamma_arr)*rth2xyz(0, 0, TA)'*(v_f_xyz - v_arr_xyz);
    dv2 = norm(dv2_vnb);
    % fprintf('DeltaV2 to enter Lunar Parking Orbit = %.4f km/s \n', dv2);

    dv_tot = dv1+dv2;
    % fprintf('\nTotal Lambert DeltaV = %.4f km/s', dv_tot);