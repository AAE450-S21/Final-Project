%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% function rth2xyz
% 
% Description: Outputs a rotation matrix between the rotating orbital unit
% vectors (r_hat, theta_hat, h_hat) and the inertial xyz system
% 
% Inputs:
% Omega: Longitude of the ascending node (�)
% i: Inclination (�)
% theta: True anomaly + argument of periapsis
% 
% Outputs:
% rot_mat: Rotation matrix (DCM)
% 
% NOTES: The rotation matrix should be right multiplied to convert from rth
% to the xyz system
function rot_mat = rth2xyz(Omega, i, theta)
    rot_mat=zeros(3);
    
    rot_mat(1,1) = cosd(theta)*cosd(Omega)-cosd(i)*sind(Omega)*sind(theta);
    rot_mat(1,2) = -sind(theta)*cosd(Omega)-cosd(theta)*cosd(i)*sind(Omega);
    rot_mat(1,3) = sind(i)*sind(Omega);
    
    rot_mat(2, 1) = cosd(theta)*sind(Omega)+sind(theta)*cosd(i)*cosd(Omega);
    rot_mat(2, 2) = -sind(theta)*sind(Omega)+cosd(theta)*cosd(i)*cosd(Omega);
    rot_mat(2, 3) = -sind(i)*cosd(Omega);
    
    rot_mat(3,1) = sind(i)*sind(theta);
    rot_mat(3,2) = cosd(theta)*sind(i);
    rot_mat(3,3) = cosd(i);
    
    
  