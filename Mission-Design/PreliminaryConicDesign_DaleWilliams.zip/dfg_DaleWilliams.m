%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% function dfg
% 
% Description:
% Determines f_dot and g_dot coefficients from initial position vector,
% velocity vector, true anomaly, semilatus rectum and gravitaitonal
% parameter.
% 
% Inputs:
% r0_vect: Initial position vector (km)
% v0_vect: Initial velocity vector (km/s)
% TA: Change in true anomaly (generally transfer angle)
% p: Semilatus rectum (km)
% mu: Gravitational paramter (km^3/s^2)
% 
% Outputs
% df: f_dot coefficient
% dg: g_dot coefficient
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [df, dg] = dfg(r0_vect, v0_vect,TA, p, mu)
    r0 = norm(r0_vect);
    df = dot(r0_vect,v0_vect)/(p*r0)*(1-cosd(TA))-1/r0*sqrt(mu/p)*sind(TA);
    dg = 1-r0/p*(1-cosd(TA));
end
