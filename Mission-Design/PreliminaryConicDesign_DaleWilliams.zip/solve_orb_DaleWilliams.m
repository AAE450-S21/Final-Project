%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% function solve_orb
%
% Description: Function to be sent to a solver to compute orbit angles from
% right ascension and declination
% 
% This function should NOT be modified.  It serves only as a "helper" for
% Conic3D
% 
% Inputs: 
% x: guess value for solver
% x(1): guessed RAAN (�)
% x(2): guessed THETA (True anomaly + argument of periapsis) (�)
% alpha: Right ascension (�)
% delta: Declination (�)
% i: Set inclination (�) - Generally should be 28.5 for Canaveral launch
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function orb_angles = solve_orb(x, alpha, delta, i)
    
    orb_angles(1) = cosd(x(1))*cosd(x(2))-sind(x(1))*cosd(i)*sind(x(2))-...
        cosd(delta)*cosd(alpha);
    orb_angles(2) = sind(x(1))*cosd(x(2))+cosd(x(1))*cosd(i)*sind(x(2))-...
        cosd(delta)*sind(alpha);
    orb_angles(3) = sind(i)*sind(x(2))-sind(delta);
