%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% function fg
% 
% Descriptions: Computes f and g coefficients from initial radius, final
% radius, transfer angle (change in true anomaly), semilatus rectum and
% gravitational parameter:
% 
% Inputs:
% r0: Initial radius (km)
% rf: Final radius (km)
% TA: Transfer angle (change in true anomaly) (�)
% p: Semilatus rectum (km)
% mu: Gravitaional parameter (km^3/s^2)
% 
% Outputs
% f: f-coefficient
% g: g-coefficient
function [f, g] = fg(r0, rf, TA, p, mu)
    f = 1-rf/p*(1-cosd(TA));
    g = rf*r0/sqrt(mu*p)*sind(TA);