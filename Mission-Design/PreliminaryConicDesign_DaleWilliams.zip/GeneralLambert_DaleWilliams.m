%% General Lambert Computation Function
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Description: General Purpose Lambert Problem solver.  Computes a conic
% orbit through two points at different radii from Earth in the two body
% problem.
% 
% Inputs: 
% TA: Transfer Angle (�) 
% TOF: Time of Flight (seconds) 
% rDep: Departure Radius (km) 
% rArr: Arrival Radius (km)
% 
% Outputs: 
% theta_star_dep: True anomaly at departure (�) 
% theta_star_arr: True anomaly at arrival (�) 
% a: Transfer orbit semimajor axis 
% e: Transfer orbit eccentricity 
% dv1_vnb: Vector containing delta-v components in the VNB coordinate system
% 
% Notes: Other quantities are solved for within the script that may be of
% interest to the user.  One can modify the output vector to include such
% quantities.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [theta_star_dep, theta_star_arr, a, e, dv1_vnb] = GeneralLambert(TA, TOF, rDep, rArr)
    mu = 3.986e5;
    if TA < 180
        TRANSFER_NUM = 1; % Transfer Type Number (1 or 2)
    else
        TRANSFER_NUM = 2;
    end

    %% Departure Quantities and Space Triangle Geometry
    if TRANSFER_NUM == 1
        c = sqrt(rDep^2+rArr^2-2*rDep*rArr*cosd(TA));
    else
        c = sqrt(rDep^2+rArr^2-2*rDep*rArr*cosd(360-TA));
    end

    % Compute Space Triangle Semi-Perimeter
    s = (rArr+rDep+c)/2;

    %% Parabolic TOF and Transfer Type
    a_min = s/2;
    TOF_min = 0;

    % Determine Parabolic TOF
    if TRANSFER_NUM == 1
        TOF_par = 1/3*sqrt(2/mu)*(s^(3/2)-(s-c)^(3/2)); 

    else
        TOF_par = 1/3*sqrt(2/mu)*(s^(3/2)+(s-c)^(3/2));
    end

    %% Determine Transfer Geometry (ELLIPIC or HYPERBOLIC)
    if TOF > TOF_par
        TRANSFER_GEOMETRY = "ELLIPTIC";
        alpha_min = 2*asin(sqrt(s/(2*a_min)));
        beta_min = 2*asin(sqrt((s-c)/(2*a_min)));
        TOF_min = sqrt(a_min^3/mu)*((alpha_min-beta_min)-(sin(alpha_min)-sin(beta_min)));

        if TOF>TOF_min
            TRANSFER_TYPE = num2str(TRANSFER_NUM)+"B";
        else
            TRANSFER_TYPE = num2str(TRANSFER_NUM)+"A";
        end

    else
        TRANSFER_GEOMETRY = "HYPERBOLIC";
        TRANSFER_TYPE = num2str(TRANSFER_NUM)+"H";
    end

    %% Select Appropriate alpha/beta fcns
    alpha_fcn = @(a) 0;
    beta_fcn = @(b) 0;
    lambert_fcn = @(a) 0;

    switch TRANSFER_TYPE
        case "1A"
            alpha_fcn = @(a) 2*asin(sqrt(s/(2*a)));
            beta_fcn = @(a) 2*asin(sqrt((s-c)/(2*a)));
        case "2B"
            alpha_fcn = @(a) 2*pi-2*asin(sqrt(s/(2*a)));
            beta_fcn = @(a) -2*asin(sqrt((s-c)/(2*a)));
        case "1B"
            alpha_fcn = @(a) 2*pi - 2*asin(sqrt(s/(2*a)));
            beta_fcn = @(a) 2*asin(sqrt((s-c)/(2*a)));
        case "2A"
            alpha_fcn = @(a) 2*asin(sqrt(s/(2*a)));
            beta_fcn = @(a) -2*asin(sqrt((s-c)/(2*a)));
        case "1H"
            alpha_fcn = @(a) 2*asinh(sqrt(s/(2*abs(a))));
            beta_fcn = @(a) 2*asinh(sqrt((s-c)/(2*abs(a))));
        case "2H"
             alpha_fcn = @(a) 2*asinh(sqrt(s/(2*abs(a))));
              beta_fcn = @(a) -2*asinh(sqrt((s-c)/(2*abs(a))));
    end

    %% Select Appropriate lambert function
    guess = a_min;
    switch TRANSFER_GEOMETRY
        case "ELLIPTIC"
            lambert_fcn = @(a) sqrt(a^3/mu)*((alpha_fcn(a)-sin(alpha_fcn(a)))-...
                (beta_fcn(a)-sin(beta_fcn(a))))-TOF;
            guess = a_min;
        case "HYPERBOLIC"
            lambert_fcn = @(a) sqrt(abs(a)^3/mu)*((sinh(alpha_fcn(a))-alpha_fcn(a))-...
                (sinh(beta_fcn(a))-beta_fcn(a)))-TOF;
            guess = -(rDep+rArr)/2;
    end

    %% Solve Lambert
    a = fsolve(lambert_fcn, guess);
    alpha_val = alpha_fcn(a);
    beta_val = beta_fcn(a);
    if abs(lambert_fcn(a)) > 1e-4
        fprintf("ERROR! BAD A");
        5/0;
    end

    %% Compute p
    % Elliptic Case
    if TRANSFER_GEOMETRY == "ELLIPTIC"
        p1 = 4*a*(s-rDep)*(s-rArr)/c^2*(sin((alpha_val+beta_val)/2))^2;
        p2 = 4*a*(s-rDep)*(s-rArr)/c^2*(sin((alpha_val-beta_val)/2))^2;

        if TRANSFER_TYPE == "1A" || TRANSFER_TYPE == "2B"
            p = max(p1, p2);
        else
            p = min(p1,p2);
        end

    % Hyperbolic Case    
    else
        p1 = 4*abs(a)*(s-rDep)*(s-rArr)/c^2*(sinh((alpha_val+beta_val)/2))^2;
        p2 = 4*abs(a)*(s-rDep)*(s-rArr)/c^2*(sinh((alpha_val-beta_val)/2))^2;
        if TRANSFER_TYPE == "1H"
            p = max(p1, p2);
        else
            p = min(p1,p2);
        end
    end

    %% General Orbit Characteristics
    if TRANSFER_GEOMETRY == "ELLIPTIC"
        e = sqrt(1-p/a);
    else
        e = sqrt(1+p/abs(a));
    end

    spec_E = -mu/(2*a);
    v_dep = sqrt(2*(spec_E+mu/rDep));
    v_arr = sqrt(2*(spec_E+mu/rArr));

    [theta_star_dep, theta_star_arr] = get_theta_star(p, e, rDep, rArr, TA);

    gamma_dep = sign(theta_star_dep)*acosd(sqrt(mu*p)/(rDep*v_dep));
    gamma_arr = sign(theta_star_arr)*acosd(sqrt(mu*p)/(rArr*v_arr));

    rp = a*(1-e);
    ra = a*(1+e);

    %% Delta-Vs Using F and G

    v_0_xyz = sqrt(mu/rDep)*[0 1 0]';
    v_f_xyz = sqrt(mu/rArr)*[cosd(TA+90) sind(TA+90) 0]';

    r_dep_xyz = rDep * [1 0 0]';
    r_arr_xyz = rArr * [cosd(TA) sind(TA) 0]';

    [f, g] = fg(rDep, rArr, TA, p, mu);

    v_dep_xyz = (r_arr_xyz - r_dep_xyz*f)/g;

    [df, dg] = dfg(r_dep_xyz, v_dep_xyz, TA, p, mu);

    v_arr_xyz = df*r_dep_xyz + dg*v_dep_xyz;

    dv1_vnb = rt2vnb(0)*rth2xyz(0, 0, 0)'*(v_dep_xyz-v_0_xyz);
    dv2_vnb = rt2vnb(gamma_arr)*rth2xyz(0, 0, TA)'*(v_f_xyz - v_arr_xyz);

    dv1 = norm(dv1_vnb);
    dv2 = norm(dv2_vnb);
    dv_tot = dv1+dv2;
end