%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Conic3D:
% 
% Description: This script allows the user to input the characteristics of
% a desired 2D Lambert transfer (TOF, TA, and departure radius) and an 
% Earth departure inclination.  It then will output the corresponding 3D
% orbital characteristics and generate the beginnings of a GMAT script with
% a spacecraft in this transfer orbit.  The script also outputs the delta-v
% values associated with all computed trajectories as a vector
% 
% Inputs:
% TOFDays: Time of flight (days)
% TA: Transfer Angle (�)
% INC: Earth departure inclination (default to 28.5�)
% rDep: Earth departure radius (km)
% ephemerisFilename: String representing a csv version of a JPL Horizons
%                    database ephemeris file
% 
% Outputs:
% GMAT script files corresponding to transfer orbits at various Epochs
% dv_vals: Associated delta-v values for each computed trajectory/epoch
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Inputs
TOFDays = 4.25;
TOF = TOFDays*3600*24;
TA = 175;
INC = 28.5;
rDep = 600+6378.14;
ephemerisFilename = 'July2022EphemerisCSV.csv';
%% Read in Ephemeris Data and Declare Output File
ephDat = csvread(ephemerisFilename);

arrEpochs = ephDat(:,2);
alpha = ephDat(:,3); % RA
delta = ephDat(:,4); % DEC
rArr = ephDat(:,5); % Arrival RMAG

dv_vals = zeros(length(rArr), 3);

for i = 1:length(rArr)
    [dep_TA, arr_TA, a,e, dv] = GeneralLambert(TA, TOF, rDep, rArr(i));
    solve_fun = @(x) solve_orb(x, alpha(i), delta(i), INC);
    slowAngles = fsolve(solve_fun, [0 0]);
    
    RAAN = mod(slowAngles(1),360);
    Theta = mod(slowAngles(2),360);
    AOP = Theta-arr_TA;
    theta_star_dep = dep_TA;
    inc_vals = INC;
    
    sc_name = strcat("SC", string(arrEpochs(i)));
    scriptFile = strcat(sc_name, ".script");
    sc_name = strcat("SC", string(floor(arrEpochs(i))));
    writeSC(scriptFile, 'w', sc_name, arrEpochs(i)-TOFDays, a, e, INC,...
        RAAN, AOP, theta_star_dep);
    dv_vals(i,:) = dv';

end