%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% function rt2vnb
% 
% Description: Computes the rotation matrix from the r_hat, theta_hat
% rotating vector basis to the VNB coordinate system.
% 
% Inputs:
% gamma: flight path angle (�)
% 
% Ouputs:
% rot_mat: Computed rotation matrix
% 
% Note, the matrix rot_mat should be right multiplied by a vector in the
% rth coordinate systme to yield one in the vnb coordinate system
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function rot_mat = rt2vnb(gamma)
    rot_mat = [sind(gamma) cosd(gamma) 0; 0 0 1; cosd(gamma) -sind(gamma) 0];
    