%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% function writeSC
%
% Description: Helper function to output beginnings of a GMAT script with a
% spacecraft with certain initial orbit characteristics.  Utilized within
% Conics3D
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function writeSC(fileName, write_mode, sc_name, epoch, a, e, i, RAAN, AOP, TA)

    write_file = fopen(fileName, write_mode);
    fprintf(write_file, 'Create Spacecraft %s\n', sc_name);
    fprintf(write_file, 'GMAT %s.DateFormat = UTCModJulian;\n', sc_name);
    fprintf(write_file, "GMAT %s.Epoch = '%f'\n", sc_name, epoch);
    fprintf(write_file, "GMAT %s.CoordinateSystem = EarthMJ2000Eq;\n", sc_name);
    fprintf(write_file, "GMAT %s.SMA = %f;\n", sc_name, a);
    fprintf(write_file, "GMAT %s.ECC = %f;\n", sc_name, e);
    fprintf(write_file, "GMAT %s.INC = %f;\n", sc_name, i);
    fprintf(write_file, "GMAT %s.RAAN = %f;\n", sc_name, RAAN);
    fprintf(write_file, "GMAT %s.AOP = %f;\n", sc_name, AOP);
    fprintf(write_file, 'GMAT %s.TA = %f;\n', sc_name, TA);
    fclose(write_file);
end